document.getElementById("searchForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const searchTerm = document.getElementById("searchInput").value;
    // Here you can perform search functionality using the searchTerm
    // For demonstration, let's just display a message with the search term
    displayResults(`Search results for "${searchTerm}"`);
});

document.getElementById("getLocationBtn").addEventListener("click", function(event) {
    event.preventDefault();
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                // Here you can use latitude and longitude to perform location-based searches
                displayResults(`Your current location: Latitude ${latitude}, Longitude ${longitude}`);
            },
            function(error) {
                console.error("Error getting location:", error.message);
                displayResults("Error getting location. Please try again later.");
            }
        );
    } else {
        console.error("Geolocation is not supported by this browser.");
        displayResults("Geolocation is not supported by this browser.");
    }
});

function displayResults(results) {
    const resultsSection = document.getElementById("results");
    resultsSection.innerHTML = `<h2>Search Results</h2><p>${results}</p>`;
}

function searchDoctors() {
    var location = document.getElementById("locationInput").value;
    var request = {
        query: "doctor",
        location: location,
        radius: 2000000, 
    };

    var service = new google.maps.places.PlacesService(document.createElement("div"));
    service.textSearch(request, callback);
}

function callback(results, status) {
    if (status == google.maps.places.PlacesServiceStatus.OK) {
        var html = "<h2>Doctors in " + document.getElementById("locationInput").value + "</h2>";
        html += "<ul>";
        for (var i = 0; i < results.length; i++) {
            html += "<li>" + results[i].name + " - " + results[i].formatted_address + "</li>";
        }
        html += "</ul>";
        document.getElementById("results").innerHTML = html;
    } else {
        document.getElementById("results").innerHTML = "No doctors found.";
    }
}














// FindDoctor.js

document.addEventListener("DOMContentLoaded", function () {
    const searchForm = document.getElementById("searchForm");
    const searchInput = document.getElementById("searchInput");
    const resultsSection = document.getElementById("results");

    // Sample doctor details for all states of India
    const doctorsByState = {
        "Andhra Pradesh": [
            {
                name: "Dr. Rajesh Kumar",
                title: "General Practitioner",
                practiceName: "Sunrise Hospital",
                city: "Vijayawada",
                timings: "Mon-Fri: 9am-5pm",
                hospital: "Sunrise Hospital"
            },
            {
                name: "Dr. Priya Reddy",
                title: "Pediatrician",
                practiceName: "Children's Clinic",
                city: "Hyderabad",
                timings: "Mon-Fri: 8am-4pm",
                hospital: "Children's Clinic"
            }
        ],
        "Arunachal Pradesh": [
            {
                name: "Dr. Tenzin Wangmo",
                title: "Internal Medicine Specialist",
                practiceName: "Arunachal Medical Center",
                city: "Itanagar",
                timings: "Mon-Fri: 8am-6pm",
                hospital: "Arunachal Medical Center"
            }
        ],
        "New Delhi": [
            {
                name: "Dr. Sanjay Gupta",
                title: "General Practitioner",
                practiceName: "Delhi Care Clinic",
                city: "New Delhi",
                timings: "Mon-Fri: 9am-5pm",
                hospital: "Delhi Care Hospital"
            },
            {
                name: "Dr. Renu Sharma",
                title: "Dermatologist",
                practiceName: "Skin Care Center",
                city: "New Delhi",
                timings: "Mon-Fri: 10am-6pm",
                hospital: "New Delhi Skin Hospital"
            }
        ],
        "Noida": [
            {
                name: "Dr. Amit Singh",
                title: "Orthopedic Surgeon",
                practiceName: "Noida Bone Clinic",
                city: "Noida",
                timings: "Mon-Fri: 9am-5pm",
                hospital: "Noida Bone Hospital"
            }
        ],
        "Greater Noida": [
            {
                name: "Dr. Meena Patel",
                title: "Pediatrician",
                practiceName: "Child Care Clinic",
                city: "Greater Noida",
                timings: "Mon-Fri: 8am-4pm",
                hospital: "Greater Noida Child Hospital"
            }
        ],
        "Karimnagar": [
            {
                name: "Dr. Suresh Reddy",
                title: "Cardiologist",
                practiceName: "Heart Center",
                city: "Karimnagar",
                timings: "Mon-Fri: 8am-6pm",
                hospital: "Karimnagar Heart Hospital"
            }
        ],
        "Peddapalli": [
            {
                name: "Dr. Priya Devi",
                title: "Gynecologist",
                practiceName: "Women's Health Clinic",
                city: "Peddapalli",
                timings: "Mon-Fri: 10am-7pm",
                hospital: "Peddapalli Women's Hospital"
            }
        ],
        "LB Nagar": [
            {
                name: "Dr. Arjun Reddy",
                title: "Orthopedic Surgeon",
                practiceName: "OrthoCare Clinic",
                city: "LB Nagar",
                timings: "Mon-Fri: 9am-5pm",
                hospital: "LB Nagar Ortho Hospital"
            }
        ],
        "Dabra": [
            {
                name: "Dr. Anjali Sharma",
                title: "Dentist",
                practiceName: "Bright Smile Dental Clinic",
                city: "Dabra",
                timings: "Mon-Fri: 9am-6pm",
                hospital: "Dabra Dental Hospital"
            }
        ],
        "Seven Hills": [
            {
                name: "Dr. Sameer Khan",
                title: "Neurologist",
                practiceName: "Seven Hills Neuro Clinic",
                city: "Seven Hills",
                timings: "Mon-Fri: 10am-7pm",
                hospital: "Seven Hills Neuro Hospital"
            }
        ],
        "Jammu Kashmir": [
            {
                name: "Dr. Ali Khan",
                title: "Psychiatrist",
                practiceName: "Mental Health Center",
                city: "Jammu Kashmir",
                timings: "Mon-Fri: 8am-4pm",
                hospital: "Jammu Kashmir Mental Hospital"
            }
        ],
        "Mumbai": [
            {
                name: "Dr. Neha Shah",
                title: "Ophthalmologist",
                practiceName: "Vision Eye Clinic",
                city: "Mumbai",
                timings: "Mon-Fri: 9am-5pm",
                hospital: "Mumbai Eye Hospital"
            }
        ],
        "Kolkata": [
            {
                name: "Dr. Ananya Das",
                title: "ENT Specialist",
                practiceName: "Ear Nose Throat Clinic",
                city: "Kolkata",
                timings: "Mon-Fri: 8am-6pm",
                hospital: "Kolkata ENT Hospital"
            }
        ]

        // Add more states and their doctors as needed
    };

    searchForm.addEventListener("submit", function (event) {
        event.preventDefault();

        resultsSection.innerHTML = ""; // Clear previous search results

        const location = searchInput.value.trim();
        if (location === "") {
            alert("Please enter a location.");
            return;
        }

        // Display details of doctors in the entered location
        displayDoctorsDetailsByLocation(location);
    });

    // Function to display details of doctors for a specific location
    function displayDoctorsDetailsByLocation(location) {
        let foundDoctors = false;

        for (const state in doctorsByState) {
            doctorsByState[state].forEach(doctor => {
                if (doctor.city.toLowerCase() === location.toLowerCase()) {
                    const doctorDetails = `
                        <div class="doctor">
                            <h3>${doctor.name}</h3>
                            <p>Title: ${doctor.title}</p>
                            <p>Practice Name: ${doctor.practiceName}</p>
                            <p>City: ${doctor.city}</p>
                            <p>Timings: ${doctor.timings}</p>
                            <p>Hospital: ${doctor.hospital}</p>
                        </div>
                    `;
                    resultsSection.insertAdjacentHTML("beforeend", doctorDetails);
                    foundDoctors = true;
                }
            });
        }

        if (!foundDoctors) {
            resultsSection.innerHTML = `<p>No doctors found in ${location}.</p>`;
        }
    }
});
